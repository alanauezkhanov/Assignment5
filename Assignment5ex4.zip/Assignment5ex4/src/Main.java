class Character {
    String name;
    String characterClass;
    Weapon weapon;
    int health;
    int mana;

    @Override
    public String toString() {
        return "Character{" +
                "name='" + name + '\'' +
                ", characterClass='" + characterClass + '\'' +
                ", weapon=" + weapon +
                ", health=" + health +
                ", mana=" + mana +
                '}';
    }
}

class Weapon {
    String type;
    int damage;
    int speed;
    int range;

    @Override
    public String toString() {
        return "Weapon{" +
                "type='" + type + '\'' +
                ", damage=" + damage +
                ", speed=" + speed +
                ", range=" + range +
                '}';
    }
}

abstract class CharacterFactory {
    abstract Character createCharacter();
    abstract Weapon createWeapon();
}

class WarriorSwordFactory extends CharacterFactory {
    @Override
    Character createCharacter() {
        Character character = new Character();
        character.characterClass = "Warrior";
        return character;
    }

    @Override
    Weapon createWeapon() {
        Weapon weapon = new Weapon();
        weapon.type = "Sword";
        return weapon;
    }
}

class MageStaffFactory extends CharacterFactory {
    @Override
    Character createCharacter() {
        Character character = new Character();
        character.characterClass = "Mage";
        return character;
    }

    @Override
    Weapon createWeapon() {
        Weapon weapon = new Weapon();
        weapon.type = "Staff";
        return weapon;
    }
}

class ArcherBowFactory extends CharacterFactory {
    @Override
    Character createCharacter() {
        Character character = new Character();
        character.characterClass = "Archer";
        return character;
    }

    @Override
    Weapon createWeapon() {
        Weapon weapon = new Weapon();
        weapon.type = "Bow";
        return weapon;
    }
}

class CharacterCreator {
    private CharacterFactory factory;

    void setFactory(CharacterFactory factory) {
        this.factory = factory;
    }

    Character createCharacter() {
        Character character = factory.createCharacter();
        character.weapon = factory.createWeapon();
        return character;
    }
}

public class Main {
    public static void main(String[] args) {
        CharacterCreator creator = new CharacterCreator();

        CharacterFactory warriorSwordFactory = new WarriorSwordFactory();
        creator.setFactory(warriorSwordFactory);
        Character warriorWithSword = creator.createCharacter();
        warriorWithSword.name = "Warrior with Sword";
        warriorWithSword.health = 100;
        warriorWithSword.mana = 50;
        warriorWithSword.weapon.damage = 20;
        warriorWithSword.weapon.speed = 10;
        warriorWithSword.weapon.range = 5;

        CharacterFactory mageStaffFactory = new MageStaffFactory();
        creator.setFactory(mageStaffFactory);
        Character mageWithStaff = creator.createCharacter();
        mageWithStaff.name = "Mage with Staff";
        mageWithStaff.health = 80;
        mageWithStaff.mana = 100;
        mageWithStaff.weapon.damage = 15;
        mageWithStaff.weapon.speed = 5;
        mageWithStaff.weapon.range = 10;

        CharacterFactory archerBowFactory = new ArcherBowFactory();
        creator.setFactory(archerBowFactory);
        Character archerWithBow = creator.createCharacter();
        archerWithBow.name = "Archer with Bow";
        archerWithBow.health = 70;
        archerWithBow.mana = 70;
        archerWithBow.weapon.damage = 25;
        archerWithBow.weapon.speed = 15;
        archerWithBow.weapon.range = 20;

        System.out.println(warriorWithSword);
        System.out.println(mageWithStaff);
        System.out.println(archerWithBow);

        simulateOnlinePlay(warriorWithSword, mageWithStaff, archerWithBow);
    }

    private static void simulateOnlinePlay(Character... characters) {
        System.out.println("\nSimulating online play...");
        for (Character character : characters) {
            System.out.println("Player " + character.name + " is playing online.");
        }
    }

}
