public class Ability {
    private String ability;

    public Ability(String ability) {
        this.ability = ability;
    }

    public String getAbility() {
        return ability;
    }
}
