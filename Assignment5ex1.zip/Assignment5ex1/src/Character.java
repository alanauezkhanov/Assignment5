import java.util.ArrayList;
import java.util.List;

public class Character {
    private String name;
    private Appearance appearance;
    private List<Ability> abilities;
    private List<Equipment> equipment;
    private Attributes attributes;

    public Character(String name) {
        this.name = name;
        abilities = new ArrayList<>();
        equipment = new ArrayList<>();
    }

    public void setAppearance(Appearance appearance) {
        this.appearance = appearance;
    }

    public void addAbility(Ability ability) {
        abilities.add(ability);
    }

    public void addEquipment(Equipment equipment) {
        this.equipment.add(equipment);
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    public Appearance getAppearance() {
        return appearance;
    }
}
