public class MageFactory extends CharacterFactory {
    @Override
    public Character createCharacter(String name) {
        Character character = new Character(name);
        character.setAppearance(new Appearance("Mage Appearance"));
        character.addAbility(new Ability("Fireball"));
        character.addEquipment(new Equipment("Staff"));
        character.setAttributes(new Attributes(3, 5, 10));
        return character;
    }
}
