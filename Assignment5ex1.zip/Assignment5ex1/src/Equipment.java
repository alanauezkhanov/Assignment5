public class Equipment {
    private String equipment;

    public Equipment(String equipment) {
        this.equipment = equipment;
    }

    // Getter
    public String getEquipment() {
        return equipment;
    }
}
