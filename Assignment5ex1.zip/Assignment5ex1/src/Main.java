import java.util.ArrayList;
import java.util.List;

public class Main {
        public static void main(String[] args) {
            CharacterCreator creator = new CharacterCreator();

            CharacterFactory warriorFactory = new WarriorFactory();
            CharacterFactory mageFactory = new MageFactory();
            CharacterFactory archerFactory = new ArcherFactory();

            creator.setFactory(warriorFactory);
            Character warrior = creator.createCharacter("Warrior");

            creator.setFactory(mageFactory);
            Character mage = creator.createCharacter("Mage");

            creator.setFactory(archerFactory);
            Character archer = creator.createCharacter("Archer");

            System.out.println(warrior.getClass() + ": " + warrior.getAppearance().getAppearance());
            System.out.println(mage.getClass() + ": " + mage.getAppearance().getAppearance());
            System.out.println(archer.getClass() + ": " + archer.getAppearance().getAppearance());
        }
    }