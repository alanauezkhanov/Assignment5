public class ArcherFactory extends CharacterFactory {
    @Override
    public Character createCharacter(String name) {
        Character character = new Character(name);
        character.setAppearance(new Appearance("Archer Appearance"));
        character.addAbility(new Ability("Shoot"));
        character.addEquipment(new Equipment("Bow"));
        character.setAttributes(new Attributes(5, 10, 3));
        return character;
    }
}
