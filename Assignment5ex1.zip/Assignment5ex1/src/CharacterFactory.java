public abstract class CharacterFactory {
    public abstract Character createCharacter(String name);
}
