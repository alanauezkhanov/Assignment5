public class Appearance {
    private String appearance;

    public Appearance(String appearance) {
        this.appearance = appearance;
    }

    public String getAppearance() {
        return appearance;
    }
}
