public class CharacterCreator {
    private CharacterFactory factory;

    public void setFactory(CharacterFactory factory) {
        this.factory = factory;
    }

    public Character createCharacter(String name) {
        if (factory == null) {
            throw new RuntimeException("No factory set");
        }
        return factory.createCharacter(name);
    }
}
