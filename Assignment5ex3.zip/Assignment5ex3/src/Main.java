import java.util.ArrayList;
import java.util.List;

class Furniture {
    private String name;
    private String style;
    private String material;
    private float price;

    public Furniture(String name, String style, String material, float price) {
        this.name = name;
        this.style = style;
        this.material = material;
        this.price = price;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getStyle() {
        return style;
    }

    public String getMaterial() {
        return material;
    }

    public float getPrice() {
        return price;
    }
}

abstract class FurnitureFactory {
    public abstract Chair createChair();
    public abstract Table createTable();
    public abstract Sofa createSofa();
}

class ModernWoodFactory extends FurnitureFactory {
    public Chair createChair() {
        return new Chair("Modern Chair", "Modern", "Wood", 150.0f);
    }

    public Table createTable() {
        return new Table("Modern Table", "Modern", "Wood", 250.0f);
    }

    public Sofa createSofa() {
        return new Sofa("Modern Sofa", "Modern", "Wood", 500.0f);
    }
}

class TraditionalMetalFactory extends FurnitureFactory {
    public Chair createChair() {
        return new Chair("Traditional Chair", "Traditional", "Metal", 120.0f);
    }

    public Table createTable() {
        return new Table("Traditional Table", "Traditional", "Metal", 200.0f);
    }

    public Sofa createSofa() {
        return new Sofa("Traditional Sofa", "Traditional", "Metal", 450.0f);
    }
}

class IndustrialGlassFactory extends FurnitureFactory {
    public Chair createChair() {
        return new Chair("Industrial Chair", "Industrial", "Glass", 180.0f);
    }

    public Table createTable() {
        return new Table("Industrial Table", "Industrial", "Glass", 300.0f);
    }

    public Sofa createSofa() {
        return new Sofa("Industrial Sofa", "Industrial", "Glass", 550.0f);
    }
}

class Chair extends Furniture {
    public Chair(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class Table extends Furniture {
    public Table(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class Sofa extends Furniture {
    public Sofa(String name, String style, String material, float price) {
        super(name, style, material, price);
    }
}

class FurnitureCreator {
    private FurnitureFactory factory;

    public void setFactory(FurnitureFactory factory) {
        this.factory = factory;
    }

    public Chair createChair() {
        return factory.createChair();
    }

    public Table createTable() {
        return factory.createTable();
    }

    public Sofa createSofa() {
        return factory.createSofa();
    }
}

class Marketplace {
    public static void main(String[] args) {
        FurnitureCreator creator = new FurnitureCreator();

        FurnitureFactory factory = getFactory("Modern", "Wood");
        creator.setFactory(factory);

        Chair chair = creator.createChair();
        Table table = creator.createTable();
        Sofa sofa = creator.createSofa();

        System.out.println("Products Available:");
        System.out.println(chair.getName() + " - $" + chair.getPrice());
        System.out.println(table.getName() + " - $" + table.getPrice());
        System.out.println(sofa.getName() + " - $" + sofa.getPrice());
    }

    private static FurnitureFactory getFactory(String style, String material) {
        if (style.equalsIgnoreCase("Modern") && material.equalsIgnoreCase("Wood")) {
            return new ModernWoodFactory();
        } else if (style.equalsIgnoreCase("Traditional") && material.equalsIgnoreCase("Metal")) {
            return new TraditionalMetalFactory();
        } else if (style.equalsIgnoreCase("Industrial") && material.equalsIgnoreCase("Glass")) {
            return new IndustrialGlassFactory();
        }
        return null;
    }
}
