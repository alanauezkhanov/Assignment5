import java.util.HashMap;
import java.util.Map;

class Data {
    private String type;
    private Object content;

    public Data(String type, Object content) {
        this.type = type;
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public Object getContent() {
        return content;
    }
}

abstract class DataProcessor {
    public abstract void process(Data data);
}

class TextDataProcessor extends DataProcessor {
    @Override
    public void process(Data data) {
        System.out.println("Processing text data: " + data.getContent());
    }
}

class AudioDataProcessor extends DataProcessor {
    @Override
    public void process(Data data) {
        System.out.println("Processing audio data: " + data.getContent());
    }
}

class VideoDataProcessor extends DataProcessor {
    @Override
    public void process(Data data) {
        System.out.println("Processing video data: " + data.getContent());
    }
}

class DataProcessorCreator {
    private DataProcessor processor;

    public void setProcessor(DataProcessor processor) {
        this.processor = processor;
    }

    public void processData(Data data) {
        if (processor != null) {
            processor.process(data);
        } else {
            System.out.println("No processor set.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        DataProcessorCreator processorCreator = new DataProcessorCreator();
        Map<String, DataProcessor> processors = new HashMap<>();
        processors.put("text", new TextDataProcessor());
        processors.put("audio", new AudioDataProcessor());
        processors.put("video", new VideoDataProcessor());

        Data textData = new Data("text", "Sample text data");
        Data audioData = new Data("audio", "Sample audio data");
        Data videoData = new Data("video", "Sample video data");

        for (Data data : new Data[]{textData, audioData, videoData}) {
            String type = data.getType();
            if (processors.containsKey(type)) {
                processorCreator.setProcessor(processors.get(type));
                processorCreator.processData(data);
            } else {
                System.out.println("No processor available for type: " + type);
            }
        }
    }
}
